const express = require("express");
const fs = require("fs/promises");
const path = require("path");
const {dataInitialize} = require('../sevecies/database');
const { ObjectId } = require("mongodb");

const app = express();
app.use(express.urlencoded({}))
app.use(express.json())

const dataPath = path.join(__dirname, "../data.json");

const readData = async () => {
    const contents = await fs.readFile(dataPath, "utf8");
    return JSON.parse(contents);
};

module.exports = {
    async allStudent(req, res) {
        try {
            const data = await dataInitialize();
            const student = await data.collection('Users').find({deleted_at:null}).sort({id:1}).toArray();
            res.render("student_list", { student ,err:null })
        } catch (err) {
            res.status(500).render('dashboard',{err:"Server error: Cannot get page."});

        }
    },
    async studentProfile(req, res) {
        const id = String(req.params.id)
        const data = await dataInitialize();
        try {
            const student = await data.collection('Users').findOne({_id:new ObjectId(id),deleted_at:null});
           
            res.render("user", student);
        } catch (err) { 
            const student = await data.collection('Users').find({deleted_at:null}).sort({id:1}).toArray();
            res.status(500).render("student_list",{student,err:"Server error: Cannot read student data."});
        }
    },
    async studentEdit(req,res){
        const data = await dataInitialize();
        const student = data.collection('Users').findOne({_id:new ObjectId(String(req.params.id))});
        try {
            // const students = data.students.filter(s => !s.deleted_at);
            if(!student) return res.status(400).send("cannot find user")
            // console.log(student)
            res.render("edit", student);
        } catch (err) {
            res.status(500).render("user",{student ,err:"Server error: Cannot read student data."});
        }   
        
    }
}