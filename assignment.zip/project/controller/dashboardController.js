const express = require("express");
const fs = require("fs/promises");
const path = require("path");
const { ObjectId } = require("mongodb");
const {dataInitialize} = require('../sevecies/database');

const app = express();
app.use(express.urlencoded({}))
app.use(express.json())

const dataPath = path.join(__dirname, "../data.json");

const readData = async () => {
   const data= await dataInitialize()
    return data
};


module.exports = {
    async create(req, res) {
        res.render("register")
    },
    async forget(req, res) {
        res.render("forgot_password")
    },
    async dashboard(req, res) {
        try {
            const data = await dataInitialize();
            const student = data.collection('Users').find({_id:req.user.id , deleted_at:null});
            res.render("dashboard", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    },
    async profile(req, res) {
        try {
            const data = await readData();
            const student = data.collection.find();
            res.render("user", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    },

    async edit(req, res) {
        try {
            const data = await dataInitialize();
            const student = data.collection('Users').find({_id:req.user.id,deleted_at:null});
            res.render("edit", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    }
}