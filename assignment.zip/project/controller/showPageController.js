const express = require("express");
const fs = require("fs/promises");
const path = require("path");

const {dataInitialize} = require('../sevecies/database');
const { ObjectId } = require("mongodb");

const app = express();
app.use(express.urlencoded({}))
app.use(express.json())

const dataPath = path.join(__dirname, "../data.json");

const readData = async () => {
    const contents = await fs.readFile(dataPath, "utf8");
    return JSON.parse(contents);
};

        
module.exports = {
    async login(req, res) {
        res.render('login', { err: null, mess: null })
    },
    async create(req, res) {
        res.render("register", { err: null, mess: null })
    },
    async forget(req, res) {
        res.render("verify-email", { err: null, mess: null })
    },
    async reset(req, res) {
        res.render("reset-password", { err: null })
    },
    async dashboard(req, res) {
        
        try {
            const id = String(req.user.id);
            const data = await dataInitialize();
            const student = await data.collection('Users').findOne({_id:new ObjectId(id) , deleted_at:null});
            res.render("dashboard", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    },
    async profile(req, res) {
        
        try {
            const id = String(req.user.id);
            const data = await readData();
            const student = await data.collection('Users').findOne({_id:new ObjectId(id) , deleted_at:null});
            res.render("user", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    },

    async edit(req, res) {
        
        try {
            const id = String(req.user.id);
            const data = await dataInitialize();
            const student = await data.collection('Users').findOne({_id:new ObjectId(id) , deleted_at:null});
            res.render("edit", student);
        } catch (err) {
            res.status(500).send("Error reading student data.");
        }
    }
}