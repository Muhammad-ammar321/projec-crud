const express = require("express");
const { ObjectId } = require('mongodb')
const fs = require("fs/promises");
const path = require("path");
const { dataInitialize } = require("../sevecies/database");
const { stringify } = require("querystring");

const app = express();
const dataPath = path.join(__dirname, "../data.json");


app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));
app.use(express.static(path.join(__dirname, "../public")));


const readData = async () => { 
    const data = await dataInitialize()
    const students = await data.collection('Users').find().toArray()
    return {students}
};

const writeData = async (data) => {
    await fs.writeFile(dataPath, JSON.stringify(data, null, 2));
};


module.exports = {
    async create(req, res) {
        try {
            const data = await dataInitialize();  
            const student = await data.collection('Users').find().sort({id:1}).toArray()
               let newId = 1;
        if (student.length > 0) {
             newId = student[student.length - 1].newId + 1;
        }
        const created_at = new Date()
            const newStudent = { created_at,id: newId ,...req.body, deleted_at: null };  
            
            data.collection('users').insertOne(newStudent);  
            
            // await writeData(data);  

            res.redirect("/login");  
        } catch (err) {
            console.error("Error in registration:", err);
            res.status(500).send("Server Error:Cannot register new User");
        }
    },

    async update(req, res) {
      try {
        
        const data = await dataInitialize();
        const id = String(req.user.id);
        const result =  await data.collection('Users').updateOne({_id : new ObjectId(id)},{$set:req.body});

        if(result.matchedCount === 0 ) return res.status(400).send("Student not find");

        return res.redirect("/student/profile");
    } catch (error) {
        return res.status(500).send("Server error:Cannot update user ");
    }
},
async destroy(req, res) {
    try {
        const id = String(req.params.id);
        const data = await dataInitialize();
        const student = await data.collection('Users').updateOne(
            {_id: new ObjectId(id)},
            {$set:{deleted_at: new Date()}}
        )
        
        if (student.matchedCount === 0) {
            return res.status(404).send("Student not found");
        }

        res.status(200).send("Student deleted successfully");
    } catch (err) {
        // console.error(err);
        res.status(500).send("Server Error: Cannot delete user");
    }
}

    // async destroy(req, res) {
    //     const id = Number(req.params.id);
    //     try {
    //         const data = readData()
    //         const student = data.students.find(s => s.id === id);
    //         if (!student) return res.status(404).send('student_list',{err:"Can't find student"});

    //         student.deleted_at = new Date()
    //         await writeData(data)
    //         res.status(203).send('user deleted')
    //     } catch (err) {
    //         return err.message
    //     }
    // }
}
        // const index = data.students.findIndex(s => s.id === req.user.id);
        // if (index === -1) return res.status(404).send("Student not found");
        // data.students[index] = { ...data.students[index], ...req.body };