const {MongoClient} = require('mongodb')

async function dataInitialize (){
    const url = 'mongodb://127.0.0.1:27017';
    const client = new MongoClient(url)
    const dbname = "techparksData"
    try {
        await client.connect()
        console.log("connected to database")
        return client.db(dbname)
    } catch (error) {
        console.log("server error:connection failed")
        await client.close()
    }
}

module.exports = {
    dataInitialize
}
