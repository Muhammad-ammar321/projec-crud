const express = require("express");
const fs = require("fs/promises");
const path = require("path");
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.urlencoded({}))
app.use(express.json())

const dataPath = path.join(__dirname, "../data.json");

const readData = async () => {
    const contents = await fs.readFile(dataPath, "utf8");
    return JSON.parse(contents);
};

// const sessionId = Math.ceil(Math.random() * 10000)

const secret = "🤫 no data"



module.exports= {
    async attemp (req,res){
        const { email, password } = req.body || {};
        if (!email || !password) {
            return res.status(400).send("Requirement not filled");
        }
        try {
            const data = await readData();
            const students = data.students.filter(s => !s.deleted_at);

    
    
            const student = students.find(s => s.email === email.trim() && s.password === password.trim());
    
            if (student) {
                const token = jwt.sign({id:student.id},secret,{expiresIn:60*60})
                
                res.cookie("token",token,{httpOnly:true}) 
                res.render("dashboard",student)
            } else {
                    return res.status(401).render('login',{err:"Incorrect username or password"});
            }
        } catch  {
            return res.status(500).send("An error occurred while login");
        }
    }
}



